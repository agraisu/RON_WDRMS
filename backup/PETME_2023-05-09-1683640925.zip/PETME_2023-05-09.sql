/*

                                                    +--------------------------------------------------------------+

                                                    +--------------------Petme Pet Shop Database Bakups------------+

                                                    +--------------------------------------------------------------+

                                                    +--------------------------------------------------------------+

                                                    */

-- Dumping tables for database: `wdrms`


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `added_system_privilage`

DROP TABLE IF EXISTS `added_system_privilage`;
CREATE TABLE `added_system_privilage` (
  `prv_user_id` int(5) NOT NULL,
  `prv_added_id` int(5) NOT NULL,
  `prv_main_id` int(5) NOT NULL,
  KEY `prv_user_id` (`prv_user_id`),
  KEY `prv_added_id` (`prv_added_id`),
  CONSTRAINT `added_system_privilage_ibfk_1` FOREIGN KEY (`prv_user_id`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE,
  CONSTRAINT `added_system_privilage_ibfk_2` FOREIGN KEY (`prv_added_id`) REFERENCES `system_privilages` (`prv_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: added_system_privilage

INSERT INTO `added_system_privilage` VALUES('1', '102', '100');
INSERT INTO `added_system_privilage` VALUES('2', '201', '200');
INSERT INTO `added_system_privilage` VALUES('2', '202', '200');
INSERT INTO `added_system_privilage` VALUES('2', '203', '200');
INSERT INTO `added_system_privilage` VALUES('3', '201', '200');
INSERT INTO `added_system_privilage` VALUES('3', '203', '200');
INSERT INTO `added_system_privilage` VALUES('3', '204', '200');
INSERT INTO `added_system_privilage` VALUES('4', '202', '200');
INSERT INTO `added_system_privilage` VALUES('4', '101', '100');
INSERT INTO `added_system_privilage` VALUES('4', '102', '100');
INSERT INTO `added_system_privilage` VALUES('4', '203', '200');
INSERT INTO `added_system_privilage` VALUES('4', '204', '200');
INSERT INTO `added_system_privilage` VALUES('1', '101', '100');
INSERT INTO `added_system_privilage` VALUES('4', '201', '200');
INSERT INTO `added_system_privilage` VALUES('4', '301', '300');
INSERT INTO `added_system_privilage` VALUES('4', '302', '300');
INSERT INTO `added_system_privilage` VALUES('4', '401', '400');
INSERT INTO `added_system_privilage` VALUES('4', '402', '400');
INSERT INTO `added_system_privilage` VALUES('4', '501', '500');
INSERT INTO `added_system_privilage` VALUES('4', '502', '500');
INSERT INTO `added_system_privilage` VALUES('4', '601', '600');


-- Dumping structure for table: `customer_details`

DROP TABLE IF EXISTS `customer_details`;
CREATE TABLE `customer_details` (
  `cus_id` int(6) NOT NULL AUTO_INCREMENT,
  `cus_regi_no` varchar(10) NOT NULL,
  `cus_name` varchar(255) NOT NULL,
  `cus_gender` varchar(100) NOT NULL,
  `cus_nic` varchar(12) DEFAULT NULL,
  `cus_email` varchar(255) NOT NULL,
  `cus_contact` int(15) NOT NULL,
  `cus_address` varchar(255) DEFAULT NULL,
  `cus_status` int(155) NOT NULL DEFAULT 1,
  `cus_regi_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`cus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;



-- Dumping data for table: customer_details

INSERT INTO `customer_details` VALUES('9', 'C00001', 'Nayoma Perera', 'Female', '967878687V', 'nayoma@gmail.com', '778789788', 'Kegalle', '1', '2023-02-22 17:05:34');
INSERT INTO `customer_details` VALUES('11', 'C00002', 'Kumudu Peris', 'Female', '956767878V', 'kumudu@gmail.com', '715676876', 'Kegalle', '1', '2023-02-24 12:12:03');
INSERT INTO `customer_details` VALUES('15', 'C00003', 'Ashen Silva', 'Male', '912345676V', 'ashen@gmail.com', '778987876', 'Kegalle', '1', '2023-03-30 07:32:01');
INSERT INTO `customer_details` VALUES('16', 'C00004', 'Sarath Gamage', 'Male', '887867576V', 'sarath@gmail.com', '773453432', 'Mawanella', '1', '2023-03-30 07:33:08');


-- Dumping structure for table: `damage_item_details`

DROP TABLE IF EXISTS `damage_item_details`;
CREATE TABLE `damage_item_details` (
  `dmg_tbl_id` int(10) NOT NULL AUTO_INCREMENT,
  `dmg_item_id` int(10) NOT NULL,
  `dmg_itm_note` varchar(200) DEFAULT NULL,
  `dmg_itm_qty` int(10) NOT NULL,
  `dmg_itm_added_date` datetime NOT NULL DEFAULT current_timestamp(),
  `dmg_itm_added_user` int(2) NOT NULL,
  `dmg_itm_status` int(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`dmg_tbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



-- Dumping data for table: damage_item_details

INSERT INTO `damage_item_details` VALUES('1', '3', 'removed', '1', '2023-04-19 11:04:48', '4', '1');
INSERT INTO `damage_item_details` VALUES('2', '3', '', '1', '2023-04-19 11:13:58', '4', '1');
INSERT INTO `damage_item_details` VALUES('3', '3', 'test', '2', '2023-04-19 11:31:23', '4', '1');
INSERT INTO `damage_item_details` VALUES('4', '4', 'test 2', '1', '2023-04-19 11:33:16', '4', '1');


-- Dumping structure for table: `design_details`

DROP TABLE IF EXISTS `design_details`;
CREATE TABLE `design_details` (
  `design_id` int(10) NOT NULL AUTO_INCREMENT,
  `design_name` varchar(100) NOT NULL,
  `fabric_id` int(10) NOT NULL,
  `design_status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
  PRIMARY KEY (`design_id`),
  KEY `fabric_id` (`fabric_id`),
  CONSTRAINT `design_details_ibfk_1` FOREIGN KEY (`fabric_id`) REFERENCES `fabric_details` (`fabric_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;



-- Dumping data for table: design_details

INSERT INTO `design_details` VALUES('1', 'Floral', '1', '1');
INSERT INTO `design_details` VALUES('2', 'Diamond', '1', '1');
INSERT INTO `design_details` VALUES('3', 'Plain', '1', '1');
INSERT INTO `design_details` VALUES('4', 'Embroidered', '3', '1');
INSERT INTO `design_details` VALUES('5', 'Heavy border', '3', '1');
INSERT INTO `design_details` VALUES('6', 'plain', '4', '1');
INSERT INTO `design_details` VALUES('7', 'Long Sleeve', '4', '1');
INSERT INTO `design_details` VALUES('8', 'Short Sleeve', '4', '1');
INSERT INTO `design_details` VALUES('9', 'Striped', '14', '1');
INSERT INTO `design_details` VALUES('10', 'Shiny Long Sleeve', '5', '1');
INSERT INTO `design_details` VALUES('11', 'Shiny Short Sleeve', '5', '1');
INSERT INTO `design_details` VALUES('12', 'Floral Short Sleeve', '6', '1');
INSERT INTO `design_details` VALUES('13', 'Floral Long Sleeve', '6', '1');
INSERT INTO `design_details` VALUES('14', 'Plain', '8', '1');
INSERT INTO `design_details` VALUES('15', 'Plain', '9', '1');
INSERT INTO `design_details` VALUES('16', 'Plain', '10', '1');
INSERT INTO `design_details` VALUES('17', 'Plain Pink Scarf', '9', '1');
INSERT INTO `design_details` VALUES('18', 'Plain Brown Scarf', '9', '1');
INSERT INTO `design_details` VALUES('19', 'Plain ', '11', '1');
INSERT INTO `design_details` VALUES('20', 'Plain ', '12', '1');
INSERT INTO `design_details` VALUES('21', 'Plain ', '13', '1');
INSERT INTO `design_details` VALUES('22', 'Striped', '11', '1');
INSERT INTO `design_details` VALUES('23', 'Plain', '2', '1');
INSERT INTO `design_details` VALUES('24', 'Floral', '2', '1');
INSERT INTO `design_details` VALUES('25', 'Plain', '14', '1');


-- Dumping structure for table: `fabric_details`

DROP TABLE IF EXISTS `fabric_details`;
CREATE TABLE `fabric_details` (
  `fabric_id` int(10) NOT NULL AUTO_INCREMENT,
  `fabric_name` varchar(100) NOT NULL,
  `category_id` int(10) NOT NULL,
  `fabric_status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
  PRIMARY KEY (`fabric_id`),
  UNIQUE KEY `category_id` (`category_id`,`fabric_name`) USING BTREE,
  CONSTRAINT `fabric_details_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `item_category_details` (`cat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;



-- Dumping data for table: fabric_details

INSERT INTO `fabric_details` VALUES('1', 'Cotton', '1', '1');
INSERT INTO `fabric_details` VALUES('2', 'Silk', '1', '1');
INSERT INTO `fabric_details` VALUES('3', 'Rayon', '1', '1');
INSERT INTO `fabric_details` VALUES('4', 'Cotton', '2', '1');
INSERT INTO `fabric_details` VALUES('5', 'Silk', '2', '1');
INSERT INTO `fabric_details` VALUES('6', 'Cotton', '3', '1');
INSERT INTO `fabric_details` VALUES('7', 'Silk', '3', '0');
INSERT INTO `fabric_details` VALUES('8', 'Rayon', '3', '1');
INSERT INTO `fabric_details` VALUES('9', 'Cotton', '4', '1');
INSERT INTO `fabric_details` VALUES('10', 'Silk', '4', '1');
INSERT INTO `fabric_details` VALUES('11', 'Cotton', '5', '1');
INSERT INTO `fabric_details` VALUES('12', 'Silk', '5', '1');
INSERT INTO `fabric_details` VALUES('13', 'Linen', '5', '1');
INSERT INTO `fabric_details` VALUES('14', 'Linen', '2', '1');
INSERT INTO `fabric_details` VALUES('25', 'Rayon', '5', '1');


-- Dumping structure for table: `grn_details`

DROP TABLE IF EXISTS `grn_details`;
CREATE TABLE `grn_details` (
  `grn_table_id` int(15) NOT NULL AUTO_INCREMENT,
  `grn_no` varchar(15) NOT NULL,
  `grn_date` date DEFAULT NULL,
  `sup_id` int(10) NOT NULL,
  `total_amount` decimal(50,2) NOT NULL,
  `paid_amount` decimal(50,2) NOT NULL,
  `balance_amount` decimal(50,2) NOT NULL,
  `grn_added_user` int(5) NOT NULL,
  `grn_added_date_time` datetime DEFAULT current_timestamp(),
  `grn_status` int(2) DEFAULT 1 COMMENT '1=active, 0=inactive',
  PRIMARY KEY (`grn_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;



-- Dumping data for table: grn_details

INSERT INTO `grn_details` VALUES('8', 'G00008', '2023-04-09', '6', '22750.00', '22750.00', '0.00', '4', '2023-04-09 16:03:59', '1');
INSERT INTO `grn_details` VALUES('9', 'G00009', '2023-04-09', '12', '7000.00', '500.00', '6500.00', '4', '2023-04-09 16:08:11', '1');
INSERT INTO `grn_details` VALUES('10', 'G000010', '2023-04-10', '12', '4000.00', '0.00', '4000.00', '4', '2023-04-10 11:40:30', '1');
INSERT INTO `grn_details` VALUES('11', 'G000011', '2023-04-10', '13', '4000.00', '2500.00', '1500.00', '4', '2023-04-10 21:06:32', '1');
INSERT INTO `grn_details` VALUES('12', 'G000012', '2023-04-11', '6', '9000.00', '9000.00', '0.00', '4', '2023-04-11 15:02:39', '1');
INSERT INTO `grn_details` VALUES('13', 'G000013', '2023-04-11', '6', '19000.00', '0.00', '19000.00', '4', '2023-04-11 15:35:15', '1');


-- Dumping structure for table: `grn_item_details`

DROP TABLE IF EXISTS `grn_item_details`;
CREATE TABLE `grn_item_details` (
  `grn_itm_tbl_id` int(10) NOT NULL AUTO_INCREMENT,
  `grn_no` varchar(15) DEFAULT '',
  `item_id` int(5) NOT NULL,
  `total_qty` int(5) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `rent_price` decimal(15,2) NOT NULL,
  `last_update_user` int(2) NOT NULL,
  `last_update_date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active, 0=in_active',
  PRIMARY KEY (`grn_itm_tbl_id`),
  UNIQUE KEY `grn_no` (`grn_no`,`item_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `grn_item_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_details` (`item_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;



-- Dumping data for table: grn_item_details

INSERT INTO `grn_item_details` VALUES('34', 'G000012', '3', '6', '1500.00', '0.00', '4', '2023-04-11 15:02:36', '1');
INSERT INTO `grn_item_details` VALUES('35', 'G000013', '4', '5', '2000.00', '0.00', '4', '2023-04-11 15:34:48', '1');
INSERT INTO `grn_item_details` VALUES('36', 'G000013', '7', '6', '1500.00', '0.00', '4', '2023-04-11 15:35:04', '1');


-- Dumping structure for table: `invoice_details`

DROP TABLE IF EXISTS `invoice_details`;
CREATE TABLE `invoice_details` (
  `inv_tbl_id` int(10) NOT NULL AUTO_INCREMENT,
  `inv_no` varchar(10) NOT NULL,
  `inv_cus_id` int(5) NOT NULL,
  `inv_amount` decimal(15,2) NOT NULL,
  `inv_paid_amt` decimal(15,2) NOT NULL,
  `inv_balance_amt` decimal(15,2) NOT NULL,
  `inv_discount_amt` decimal(15,2) NOT NULL,
  `inv_added_user` int(2) NOT NULL,
  `inv_added_date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `inv_status` int(2) NOT NULL DEFAULT 1 COMMENT '1 = active, 2 = closed',
  `inv_remind_status` int(2) NOT NULL DEFAULT 0 COMMENT '0= not sent, 1= sent',
  `inv_issue_date` date DEFAULT NULL,
  `inv_return_date` date DEFAULT NULL,
  `inv_fine_reminder` int(2) DEFAULT 0,
  PRIMARY KEY (`inv_tbl_id`),
  KEY `inv_no` (`inv_no`),
  KEY `inv_cus_id` (`inv_cus_id`),
  KEY `inv_added_user` (`inv_added_user`),
  CONSTRAINT `invoice_details_ibfk_1` FOREIGN KEY (`inv_cus_id`) REFERENCES `customer_details` (`cus_id`) ON UPDATE CASCADE,
  CONSTRAINT `invoice_details_ibfk_2` FOREIGN KEY (`inv_added_user`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;



-- Dumping data for table: invoice_details

INSERT INTO `invoice_details` VALUES('8', 'INV0008', '11', '5400.00', '5400.00', '1500.00', '0.00', '4', '2023-04-11 15:30:39', '2', '1', '2023-04-24', '2023-02-21', '1');
INSERT INTO `invoice_details` VALUES('9', 'INV0009', '11', '17900.00', '17900.00', '6500.00', '0.00', '4', '2023-04-11 15:37:36', '2', '1', '2023-04-24', '2023-03-27', '0');
INSERT INTO `invoice_details` VALUES('10', 'INV00010', '15', '10600.00', '10600.00', '4000.00', '0.00', '4', '2023-04-11 15:53:08', '2', '1', '2023-04-11', '2023-04-21', '1');


-- Dumping structure for table: `invoice_item_details`

DROP TABLE IF EXISTS `invoice_item_details`;
CREATE TABLE `invoice_item_details` (
  `inv_itm_tbl_id` int(20) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(10) NOT NULL,
  `inv_itm_id` int(10) NOT NULL,
  `inv_itm_qty` int(5) NOT NULL,
  `inv_unit_price` decimal(15,2) NOT NULL,
  `inv_itm_status` int(2) DEFAULT 1,
  `inv_itm_added_date_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`inv_itm_tbl_id`),
  UNIQUE KEY `invoice_no` (`invoice_no`,`inv_itm_id`),
  KEY `inv_itm_id` (`inv_itm_id`),
  CONSTRAINT `invoice_item_details_ibfk_2` FOREIGN KEY (`inv_itm_id`) REFERENCES `item_details` (`item_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;



-- Dumping data for table: invoice_item_details

INSERT INTO `invoice_item_details` VALUES('13', 'INV0008', '3', '2', '2700.00', '1', '2023-04-11 15:30:32');
INSERT INTO `invoice_item_details` VALUES('14', 'INV0009', '3', '2', '2700.00', '1', '2023-04-11 15:36:35');
INSERT INTO `invoice_item_details` VALUES('15', 'INV0009', '4', '2', '2650.00', '1', '2023-04-11 15:36:54');
INSERT INTO `invoice_item_details` VALUES('16', 'INV0009', '7', '2', '3600.00', '1', '2023-04-11 15:37:18');
INSERT INTO `invoice_item_details` VALUES('17', 'INV00010', '4', '4', '2650.00', '1', '2023-04-11 15:52:57');


-- Dumping structure for table: `item_category_details`

DROP TABLE IF EXISTS `item_category_details`;
CREATE TABLE `item_category_details` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(155) NOT NULL,
  `cat_status` int(2) NOT NULL DEFAULT 1,
  `created_user` int(5) NOT NULL DEFAULT 4,
  PRIMARY KEY (`cat_id`),
  KEY `created_user` (`created_user`),
  CONSTRAINT `item_category_details_ibfk_1` FOREIGN KEY (`created_user`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;



-- Dumping data for table: item_category_details

INSERT INTO `item_category_details` VALUES('1', 'Saree', '1', '4');
INSERT INTO `item_category_details` VALUES('2', 'Shirt', '1', '4');
INSERT INTO `item_category_details` VALUES('3', 'Coat', '1', '4');
INSERT INTO `item_category_details` VALUES('4', 'National Kit', '1', '4');
INSERT INTO `item_category_details` VALUES('5', 'Tie', '1', '4');


-- Dumping structure for table: `item_details`

DROP TABLE IF EXISTS `item_details`;
CREATE TABLE `item_details` (
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(10) NOT NULL,
  `item_category` int(5) NOT NULL,
  `fabric_type` int(5) NOT NULL,
  `design_type` int(5) NOT NULL,
  `color` varchar(100) NOT NULL,
  `size` int(5) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `item_rent_price` decimal(15,2) NOT NULL,
  `item_status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive, 99=temoporaly deactive',
  `item_added_date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `item_added_user` int(5) DEFAULT 4,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_name` (`item_name`),
  KEY `item_added_user` (`item_added_user`),
  KEY `item_category` (`item_category`),
  CONSTRAINT `item_details_ibfk_1` FOREIGN KEY (`item_added_user`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE,
  CONSTRAINT `item_details_ibfk_2` FOREIGN KEY (`item_category`) REFERENCES `item_category_details` (`cat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;



-- Dumping data for table: item_details

INSERT INTO `item_details` VALUES('1', 'I000001', '1', '1', '1', 'Red', '1', 'Floral Red Cotton Saree 6.25 M', '', '2500.00', '1', '2023-03-15 20:55:19', '4');
INSERT INTO `item_details` VALUES('2', 'I000002', '1', '1', '1', 'Blue', '1', 'Floral Blue Cotton Saree 6.25 M', '', '2450.00', '1', '2023-03-15 21:06:46', '4');
INSERT INTO `item_details` VALUES('3', 'I000004', '2', '4', '6', 'Red', '2', 'plain Red Cotton Shirt S', '', '2700.00', '1', '2023-03-15 21:13:28', '4');
INSERT INTO `item_details` VALUES('4', 'I000005', '2', '4', '6', 'Pink', '2', 'plain Cotton Pink Shirt S', '', '2650.00', '1', '2023-03-15 21:14:11', '1');
INSERT INTO `item_details` VALUES('5', 'I000005', '3', '8', '14', 'Black', '2', 'Plain Black Rayon Coat S', '', '2800.00', '1', '2023-03-16 13:36:26', '4');
INSERT INTO `item_details` VALUES('6', 'I000006', '3', '8', '14', 'Blue', '1', 'Plain Blue Rayon Coat M', '', '2100.00', '1', '2023-03-16 19:19:12', '4');
INSERT INTO `item_details` VALUES('7', 'I000007', '4', '9', '15', 'Gold', '12', 'Plain Gold Cotton National Kit L', '', '3600.00', '1', '2023-03-16 19:20:14', '4');
INSERT INTO `item_details` VALUES('8', 'I000008', '4', '9', '18', 'White', '11', 'Plain Brown Scarf White Cotton National Kit M', '', '3500.00', '1', '2023-03-16 19:21:15', '4');
INSERT INTO `item_details` VALUES('9', 'I000009', '4', '9', '17', 'White', '11', 'Plain Pink Scarf White Cotton National Kit M', '', '3200.00', '1', '2023-03-16 19:22:52', '4');
INSERT INTO `item_details` VALUES('10', 'I0000010', '1', '1', '3', 'Red', '1', 'Plain Red Cotton Saree 6.25 M', '', '2460.00', '1', '2023-03-16 19:30:20', '4');
INSERT INTO `item_details` VALUES('11', 'I0000011', '5', '11', '19', 'Pink', '13', 'Plain  Pink Cotton Tie 9 CM', '', '1100.00', '1', '2023-03-16 19:30:47', '4');
INSERT INTO `item_details` VALUES('12', 'I0000012', '5', '12', '20', 'Blue', '13', 'Plain  Blue Silk Tie 9 CM', '', '1000.00', '1', '2023-03-16 19:31:44', '4');
INSERT INTO `item_details` VALUES('13', 'I0000013', '5', '11', '19', 'Red', '13', 'Plain  Red Cotton Tie 9 CM', '', '1250.00', '0', '2023-03-30 08:48:49', '4');


-- Dumping structure for table: `item_return_details`

DROP TABLE IF EXISTS `item_return_details`;
CREATE TABLE `item_return_details` (
  `return_id` int(10) NOT NULL AUTO_INCREMENT,
  `return_inv_no` varchar(10) NOT NULL,
  `return_note` varchar(150) NOT NULL,
  `return_fine_charge` decimal(15,2) DEFAULT NULL,
  `other_fine` decimal(15,2) DEFAULT NULL,
  `return_user_id` int(2) NOT NULL,
  `return_date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `return_status` int(2) NOT NULL DEFAULT 1,
  `return_type` int(2) DEFAULT 1 COMMENT '1=main_stock, 0=damaged_stock',
  `return_amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  UNIQUE KEY `return_inv_id` (`return_inv_no`) USING BTREE,
  KEY `return_user_id` (`return_user_id`),
  CONSTRAINT `item_return_details_ibfk_3` FOREIGN KEY (`return_user_id`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;



-- Dumping data for table: item_return_details

INSERT INTO `item_return_details` VALUES('21', 'INV0008', '', '0.00', '0.00', '4', '2023-04-24 15:32:08', '1', '1', '12500.00');
INSERT INTO `item_return_details` VALUES('22', 'INV0009', '', '0.00', '0.00', '4', '2023-04-24 15:39:36', '1', '1', '7500.00');
INSERT INTO `item_return_details` VALUES('23', 'INV00010', '', '0.00', '0.00', '4', '2023-04-11 15:53:28', '1', '1', '');


-- Dumping structure for table: `size_details`

DROP TABLE IF EXISTS `size_details`;
CREATE TABLE `size_details` (
  `size_id` int(10) NOT NULL AUTO_INCREMENT,
  `size` varchar(50) NOT NULL,
  `category_id` int(10) NOT NULL,
  `size_status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
  PRIMARY KEY (`size_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `size_details_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `item_category_details` (`cat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;



-- Dumping data for table: size_details

INSERT INTO `size_details` VALUES('1', '6.25 M', '1', '1');
INSERT INTO `size_details` VALUES('2', 'S', '2', '1');
INSERT INTO `size_details` VALUES('3', 'M', '2', '1');
INSERT INTO `size_details` VALUES('4', 'L', '2', '1');
INSERT INTO `size_details` VALUES('5', 'XL', '2', '1');
INSERT INTO `size_details` VALUES('6', 'S', '3', '1');
INSERT INTO `size_details` VALUES('7', 'M', '3', '1');
INSERT INTO `size_details` VALUES('8', 'L', '3', '1');
INSERT INTO `size_details` VALUES('9', 'XL', '3', '1');
INSERT INTO `size_details` VALUES('10', 'S', '4', '1');
INSERT INTO `size_details` VALUES('11', 'M', '4', '1');
INSERT INTO `size_details` VALUES('12', 'L', '4', '1');
INSERT INTO `size_details` VALUES('13', '9 CM', '5', '1');
INSERT INTO `size_details` VALUES('14', '7.5 CM', '5', '1');


-- Dumping structure for table: `supplier_details`

DROP TABLE IF EXISTS `supplier_details`;
CREATE TABLE `supplier_details` (
  `sup_id` int(6) NOT NULL AUTO_INCREMENT,
  `sup_reg_no` varchar(10) NOT NULL,
  `sup_name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_details` varchar(255) DEFAULT NULL,
  `sup_email` varchar(255) NOT NULL,
  `sup_contact` int(15) NOT NULL,
  `sup_address` varchar(255) DEFAULT NULL,
  `sup_credit_limit` decimal(50,2) DEFAULT NULL,
  `sup_status` int(2) NOT NULL DEFAULT 1,
  `sup_reg_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;



-- Dumping data for table: supplier_details

INSERT INTO `supplier_details` VALUES('6', 'S001', 'Dasun Perera', '', '', 'dasun@gmail.com', '767898789', 'Kandy', '25000.00', '1', '2023-02-26 08:22:01');
INSERT INTO `supplier_details` VALUES('9', 'S002', 'Dimuth Ranabahu', '', '', 'dimuth@gmail.com', '712343454', 'dimuth@gmail.com', '10000.00', '1', '2023-03-16 13:39:43');
INSERT INTO `supplier_details` VALUES('12', 'S003', 'Saman Gunathilaka', '', '', 'saman@gmail.com', '778987898', 'Kegalle', '15000.00', '1', '2023-03-16 19:18:38');
INSERT INTO `supplier_details` VALUES('13', 'S004', 'Asiru Raman', '', '', 'asiru@gmail.com', '2147483647', 'Kegalle', '5000.00', '1', '2023-03-16 19:29:10');


-- Dumping structure for table: `supplier_payment_transactions`

DROP TABLE IF EXISTS `supplier_payment_transactions`;
CREATE TABLE `supplier_payment_transactions` (
  `sup_pay_id` int(10) NOT NULL AUTO_INCREMENT,
  `sup_id` int(5) NOT NULL,
  `sup_grn_id` int(5) NOT NULL,
  `sup_paid_amount` decimal(10,2) NOT NULL,
  `sup_paid_user_id` int(5) NOT NULL,
  `sup_paid_date_time` datetime NOT NULL DEFAULT current_timestamp(),
  `sup_paid_status` int(2) NOT NULL DEFAULT 1 COMMENT '1=active payment , 0= cancel',
  PRIMARY KEY (`sup_pay_id`),
  KEY `sup_id` (`sup_id`),
  KEY `sup_grn_id` (`sup_grn_id`),
  KEY `sup_paid_user_id` (`sup_paid_user_id`),
  CONSTRAINT `supplier_payment_transactions_ibfk_1` FOREIGN KEY (`sup_id`) REFERENCES `supplier_details` (`sup_id`) ON UPDATE CASCADE,
  CONSTRAINT `supplier_payment_transactions_ibfk_2` FOREIGN KEY (`sup_grn_id`) REFERENCES `grn_details` (`grn_table_id`) ON UPDATE CASCADE,
  CONSTRAINT `supplier_payment_transactions_ibfk_3` FOREIGN KEY (`sup_paid_user_id`) REFERENCES `user_register` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;



-- Dumping data for table: supplier_payment_transactions

INSERT INTO `supplier_payment_transactions` VALUES('7', '6', '8', '22750.00', '4', '2023-04-11 15:54:20', '1');
INSERT INTO `supplier_payment_transactions` VALUES('8', '6', '12', '9000.00', '4', '2023-04-11 15:54:55', '1');


-- Dumping structure for table: `system_inventory`

DROP TABLE IF EXISTS `system_inventory`;
CREATE TABLE `system_inventory` (
  `item_id` int(10) NOT NULL,
  `avl_qty` int(50) NOT NULL,
  `last_update_date_time` datetime DEFAULT current_timestamp(),
  `last_update_user` int(2) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  CONSTRAINT `system_inventory_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_details` (`item_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: system_inventory

INSERT INTO `system_inventory` VALUES('3', '2', '2023-04-11 15:02:36', '4');
INSERT INTO `system_inventory` VALUES('4', '4', '2023-04-19 11:33:16', '4');
INSERT INTO `system_inventory` VALUES('7', '6', '2023-04-11 15:35:04', '4');


-- Dumping structure for table: `system_privilages`

DROP TABLE IF EXISTS `system_privilages`;
CREATE TABLE `system_privilages` (
  `prv_id` int(5) NOT NULL,
  `prv_name` varchar(50) NOT NULL,
  `prv_type` int(5) NOT NULL,
  `prv_path` varchar(100) NOT NULL,
  `prv_priority` int(3) DEFAULT NULL,
  `prv_status` int(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`prv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: system_privilages

INSERT INTO `system_privilages` VALUES('100', 'User Management', '0', '', '1', '1');
INSERT INTO `system_privilages` VALUES('101', 'User Registration', '100', './?x=user', '1', '1');
INSERT INTO `system_privilages` VALUES('102', 'System Privilage', '100', './?x=privilage', '2', '1');
INSERT INTO `system_privilages` VALUES('200', 'Registration', '0', '', '2', '1');
INSERT INTO `system_privilages` VALUES('201', 'Item Registration', '200', './?x=item', '1', '1');
INSERT INTO `system_privilages` VALUES('202', 'Customer Registration', '200', './?x=customer', '2', '1');
INSERT INTO `system_privilages` VALUES('203', 'Category Registration', '200', './?x=category', '3', '1');
INSERT INTO `system_privilages` VALUES('204', 'Supplier Registration', '200', './?x=supplier', '4', '1');
INSERT INTO `system_privilages` VALUES('300', 'GRN ', '0', '', '3', '1');
INSERT INTO `system_privilages` VALUES('301', 'Add New GRN', '300', './?x=inventory', '1', '1');
INSERT INTO `system_privilages` VALUES('302', 'Supplier Payment', '300', './?x=supplier_payment', '2', '1');
INSERT INTO `system_privilages` VALUES('400', 'Sales', '0', '', '4', '1');
INSERT INTO `system_privilages` VALUES('401', 'New Invoice', '400', './?x=invoice', '1', '1');
INSERT INTO `system_privilages` VALUES('402', 'Return', '400', './?x=item_return', '2', '1');
INSERT INTO `system_privilages` VALUES('500', 'Inventory', '0', '', '5', '1');
INSERT INTO `system_privilages` VALUES('501', 'View Inventory', '500', './?x=system_inventory', '1', '1');
INSERT INTO `system_privilages` VALUES('502', 'Damaged Items', '500', './?x=item_remove', '2', '1');
INSERT INTO `system_privilages` VALUES('600', 'Backup', '0', '', '6', '1');
INSERT INTO `system_privilages` VALUES('601', 'Get System Data Backup', '600', './?x=backup', '1', '1');


-- Dumping structure for table: `system_properties`

DROP TABLE IF EXISTS `system_properties`;
CREATE TABLE `system_properties` (
  `type` varchar(10) NOT NULL,
  `value` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: system_properties

INSERT INTO `system_properties` VALUES('late_charg', '350');
INSERT INTO `system_properties` VALUES('low_items', '5');


-- Dumping structure for table: `user_register`

DROP TABLE IF EXISTS `user_register`;
CREATE TABLE `user_register` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(155) NOT NULL,
  `user_nic` varchar(12) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_contact` int(15) NOT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` varchar(100) NOT NULL,
  `user_status` int(2) NOT NULL DEFAULT 1,
  `user_regi_date_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;



-- Dumping data for table: user_register

INSERT INTO `user_register` VALUES('1', 'Agra Wickramathilaka', '948533715V', 'agra@gmail.com', '769778780', 'kegalle', 'agraisu', '1e80de6465868f4aceb73165438a017ce198bae8', 'Admin', '1', '2023-02-16 10:28:40');
INSERT INTO `user_register` VALUES('2', 'Saduni Perera', '954565676V', 'saduni@gmail.com', '712343456', 'kegalle', 'saduni', '768fc364ccb474da672d6642c130f67bdad92591', 'Shop Manager', '1', '2023-02-16 10:36:20');
INSERT INTO `user_register` VALUES('3', 'Supun Fernando', '965676787898', 'supun@gmail.com', '776787987', 'kegalle', 'supun', '469eb0c245809a8632e4bb3adbb135c7c8838fc5', 'Cashier', '1', '2023-02-16 10:37:52');
INSERT INTO `user_register` VALUES('4', 'Admin', '956778687V', 'admin@gmail.com', '778987678', '', 'admin', '7c2e5ef540efc167254d72eacf0c1826df98b38a', 'Admin', '1', '2023-03-03 21:28:26');


SET FOREIGN_KEY_CHECKS=1; 

